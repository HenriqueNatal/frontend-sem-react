# backend-node-exemplo-memoria
Backend feito em node para ser usado de exemplo com os alunos nos cursos.
